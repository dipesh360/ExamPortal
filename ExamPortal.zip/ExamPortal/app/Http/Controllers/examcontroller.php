<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class examcontroller extends Controller
{
    public function index()
    {
        return view("user_layouts.index");
    }
    public function about()
    {
        return view("user_layouts.about");
    }
    public function login()
    {
        return view("user_layouts.login");
    }
    public function signup()
    {
        return view('user_layouts.signup');
    }
    public function contact()
    {
        return view("user_layouts.contact");
    }
}
