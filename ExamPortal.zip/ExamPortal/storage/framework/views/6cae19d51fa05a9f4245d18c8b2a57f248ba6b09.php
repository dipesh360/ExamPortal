
<?php $__env->startSection('title', 'Exam Protal | Home'); ?>

<?php $__env->startSection('main'); ?>

<div class="container my-5">
    <br><br><br><br>
    <div class="row">
        <div class="col-lg-1">

        </div>
        <div class="col-lg-4">
            <a href="/login" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/student_login.jpg')); ?>" alt="Card image cap">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Student Login</li>
                    </ul>
                </div>
            </a>
        </div>
        
        <div class="col-lg-1"></div>
        <div class="col-lg-4">
            <a href="/login" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/student_login.jpg')); ?>" alt="Card image cap">

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Admin Login</li>

                    </ul>
                </div>
            </a>
        </div>
        <div class="col-lg-2">

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<!-- Route::get('/home', [democontroller::class, 'funcname']) -->
<?php echo $__env->make('\user_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/user_layouts/index.blade.php ENDPATH**/ ?>