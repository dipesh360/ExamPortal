<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="<?php echo e(url('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">

    <title>Exam Portal | About</title>
</head>

<body>
    <!-- Header Section -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">Exam Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto mb-2 mb-lg-0 ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main section -->
    <div class="container mt-4 mb-4">
        <h3>Message From User</h3>
        <p>Name = <?php echo e($_POST['name']); ?></p>
        <p>Email = <?php echo e($_POST['email']); ?></p>
        <p>Message = <?php echo e($_POST['message']); ?></p>
    </div>



    <!-- Footer Section -->
    <footer id="footer" class="text-center">
        <span>Made with ❤️ by Dipesh, Rahul, Mukesh</span>
    </footer>

    <script src="<?php echo e(url('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(url('js/script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/show.blade.php ENDPATH**/ ?>