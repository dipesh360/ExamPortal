<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="<?php echo e(url('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">

    <!-- <title>Exam Portal | Home</title> -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">Exam Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/signup">Signup</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>



<?php echo $__env->yieldContent('main'); ?>
    
<!-- Footer Section -->
<footer id="footer" class="bg-dark text-center">
            <span>Copyright ©2022 — ExamPortal</span>
</footer>
    <script src="<?php echo e(url('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('js/popper.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(url('js/script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/\user_layouts/master.blade.php ENDPATH**/ ?>