<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="<?php echo e(url('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">

    <title>Exam Portal | Home</title>
</head>

<body>
    <!-- Header Section -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">Exam Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto mb-2 mb-lg-0 ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    

    <!-- Main section -->
    <div class="container mt-4 mb-4">
        <h3>Home</h3>
        <p>Lorem ipIpsam quis aperiam Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad molestiae, asperiores Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis, deserunt consequatur rerum nihil possimus ea similique repudiandae veritatis accusantium eaque? Nam, explicabo, totam ab adipisci reprehenderit impedit earum nisi nemo asperiores, architecto optio voluptatem eum libero nihil? Asperiores dolorem nam inventore modi, rerum id beatae blanditiis illum quaerat sed ex possimus voluptas fuga, nostrum omnis iusto delectus dicta error quisquam saepe! Cumque voluptas eius deleniti animi, voluptate nam magni tempore officiis dolorem aspernatur necessitatibus modi voluptates rerum at illo. Laudantium iste quibusdam mollitia dignissimos corporis dolorum, ea sequi illo, quasi corrupti, minima provident veniam a neque ut possimus voluptates ad. veniam ab ea neque iusto quaerat temporibus quos facilis a at voluptatem explicabo doloribus? harum, veritatis vitae voluptatem, suscipit fugit, quam fuga officia laudantium voluptas! Minima sunt accusantium necessitatibus aut magnam possimus itaque, quia exercitationem assumenda, eos earum unde esse atque. Nisi, corrupti necessitatibus? Beatae, officiis. Molestias minus cum quae. Tempora omnis minima dolores iste corrupti expedita accusantium error impedit aperiam voluptatem exercitationem aspernatur, suscipit eius consequatur consectetur nisi quam a, deserunt voluptatibus similique dolorum asperiores magnam fuga! Harum impedit iste vel recusandae facere fugiat inventore laboriosam maxime aperiam sed perferendis esse, exercitationem maiores necessitatibus ab dolore velit culpa architecto minima est temporibus magni! Maiores magnam porro voluptate inventore quisquam voluptatem repellendus officia illum, nesciunt earum quidem impedit dignissimos itaque nulla asperiores animi a sed mollitia iste aspernatur nisi molestiae doloribus cupiditate. Laudantium, veniam inventore maiores porro harum sint quaerat tempore id voluptatem omnis temporibus modi ipsum obcaecati quibusdam? Voluptatem ad, quia eius, id corrupti optio iusto itaque pariatur quae, modi quibusdam. Porro enim ratione iusto esse maiores libero distinctio quia, quibusdam laborum maxime laudantium, quisquam commodi cum deserunt atque minus fuga ipsum provident. Animi necessitatibus voluptatum eum, maiores illum commodi nam architecto culpa nulla. Alias suscipit blanditiis quia ex aspernatur illum dolorum nisi corporis cupiditate cumque numquam mollitia qui recusandae, eveniet ipsum ipsam sint? Accusantium nostrum aut itaque eum accusamus dolor magnam maiores excepturi numquam!</p>
    </div>


    <!-- Footer Section -->
    <footer id="footer" class="text-center">
        <span>Made with ❤️ by Dipesh, Rahul, Mukesh</span>
    </footer>

    <script src="<?php echo e(url('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(url('js/script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/index.blade.php ENDPATH**/ ?>