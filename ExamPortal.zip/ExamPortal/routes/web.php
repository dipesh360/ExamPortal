<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\examcontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('user_layouts.index');
// });

// Route::get('/about', function () {
//     return view('user_layouts.about');
// });

// Route::get('/contact', function () {
//     return view('user_layouts.contact');
// });

// Route::post('/show', function () {
//     return view('user_layouts.show');
// });

// Route::get('/signup', function () {
//     return view('user_layouts.register');
// });
// Route::get('/login', function () {
//     return view('user_layouts.login');
// });

Route::get('/',[examcontroller::class, 'index']);
Route::get('/login',[examcontroller::class, 'login']);
Route::get('/signup',[examcontroller::class, 'signup']);
Route::get('/show',[examcontroller::class, 'show']);
Route::get('/contact',[examcontroller::class, 'contact']);
Route::get('/about',[examcontroller::class, 'about']);