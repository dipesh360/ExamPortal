@extends('\user_layouts.master')
@section('title', 'Exam Protal | About')

@section('main')
    
    <div class="container mt-4 mb-4">
        <h3>About</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam neque doloremque quos vitae ducimus, quis nesciunt dolorum ullam est vero soluta a inventore ipsum enim. Repudiandae at consequatur, soluta sed deserunt praesentium esse non tempora? Ipsam quis aperiam harum, veritatis vitae voluptatem, suscipit fugit, quam fuga officia laudantium voluptas! Minima sunt accusantium necessitatibus aut magnam possimus itaque, quia exercitationem assumenda, eos earum unde esse atque. Nisi, corrupti necessitatibus? Beatae, officiis. Molestias minus cum quae. Tempora omnis minima dolores iste corrupti expedita accusantium error impedit aperiam voluptatem exercitationem aspernatur, suscipit eius consequatur consectetur nisi quam a, deserunt voluptatibus similique dolorum asperiores magnam fuga! Harum impedit iste vel recusandae facere fugiat inventore laboriosam maxime aperiam sed perferendis esse, exercitationem maiores necessitatibus ab dolore velit culpa architecto minima est temporibus magni! Maiores magnam porro voluptate inventore quisquam voluptatem repellendus officia illum, nesciunt earum quidem impedit dignissimos itaque nulla asperiores animi a sed mollitia iste aspernatur nisi molestiae doloribus cupiditate. Laudantium, veniam inventore maiores porro harum sint quaerat tempore id voluptatem omnis temporibus modi ipsum obcaecati quibusdam? Voluptatem ad, quia eius, id corrupti optio iusto itaque pariatur quae, modi quibusdam. Porro enim ratione iusto esse maiores libero distinctio quia, quibusdam laborum maxime laudantium, quisquam commodi cum deserunt atque minus fuga ipsum provident. Animi necessitatibus voluptatum eum, maiores illum commodi nam architecto culpa nulla. Alias suscipit blanditiis quia ex aspernatur illum dolorum nisi corporis cupiditate cumque numquam mollitia qui recusandae, eveniet ipsum ipsam sint? Accusantium nostrum aut itaque eum accusamus dolor magnam maiores excepturi numquam!</p>
    </div>

@endsection
